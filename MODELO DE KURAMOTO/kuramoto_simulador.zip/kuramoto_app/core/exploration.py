"""
Módulo 2: Exploración exhaustiva del espacio de configuraciones.

Para N y M pequeños, recorre todo el espacio Z_M^N y calcula:
  ρ_sync(κ), ρ_fix(κ), ρ_cyc(κ)

También calcula el número de Bell B_N para comparación con subredes realizables.
"""

import numpy as np
import itertools
from typing import Dict, List, Tuple
from math import factorial


def bell_number(n: int) -> int:
    """Calcula el número de Bell B_n (particiones de un conjunto de n elementos)."""
    # Triángulo de Bell
    bell = [[0] * (n + 1) for _ in range(n + 1)]
    bell[0][0] = 1
    for i in range(1, n + 1):
        bell[i][0] = bell[i-1][i-1]
        for j in range(1, i + 1):
            bell[i][j] = bell[i-1][j-1] + bell[i][j-1]
    return bell[n][0]


def all_configurations(N: int, M: int):
    """Generador de todas las configuraciones θ ∈ Z_M^N."""
    for config in itertools.product(range(M), repeat=N):
        yield np.array(config, dtype=int)


def explore_exhaustive(
    adjacency: dict,
    N: int,
    M: int,
    omega: int,
    kappa: float,
    max_steps: int = 200,
    progress_callback=None,
    base_graph=None,
) -> Dict:
    """
    Explora todas las M^N configuraciones iniciales y clasifica atractores.
    
    Returns:
        summary: dict con proporciones y conteos por tipo de atractor
        results: lista de resultados individuales (para grafos pequeños)
        sync_times: histograma de tiempos de sincronización
    """
    from core.dynamics import run_simulation

    total = M ** N
    counts = {"sync": 0, "fixed_point": 0, "cycle": 0, "transient": 0}
    sync_times = []
    cycle_lengths = []
    results = []

    for idx, theta0 in enumerate(all_configurations(N, M)):
        if progress_callback and idx % max(1, total // 20) == 0:
            progress_callback(idx / total)

        result = run_simulation(theta0, adjacency, omega, kappa, M, max_steps)
        att = result["attractor_type"]
        counts[att] += 1

        if att == "sync":
            sync_times.append(result["sync_time"])
        if att == "cycle":
            cycle_lengths.append(result["cycle_length"])

        # Guardar resultado resumido
        results.append({
            "initial": theta0.tolist(),
            "final": result["final_state"].tolist(),
            "attractor": att,
            "sync_time": result["sync_time"],
            "cycle_length": result["cycle_length"],
        })

    proportions = {k: v / total for k, v in counts.items()}

    return {
        "total_configs": total,
        "counts": counts,
        "proportions": proportions,
        "sync_times": sync_times,
        "cycle_lengths": cycle_lengths,
        "results": results,
        "bell_N": bell_number(N),
        "kappa": kappa,
        "N": N,
        "M": M,
    }


def sweep_kappa(
    adjacency: dict,
    N: int,
    M: int,
    omega: int,
    kappa_values: List[float],
    max_steps: int = 100
) -> Dict:
    """
    Barre valores de κ y calcula ρ_sync, ρ_fix, ρ_cyc para cada uno.
    Produce el mapa de regímenes dinámicos.
    """
    regime_map = {
        "kappa": kappa_values,
        "rho_sync": [],
        "rho_fix": [],
        "rho_cyc": [],
        "rho_transient": [],
    }

    for kappa in kappa_values:
        result = explore_exhaustive(adjacency, N, M, omega, kappa, max_steps)
        p = result["proportions"]
        regime_map["rho_sync"].append(p["sync"])
        regime_map["rho_fix"].append(p["fixed_point"])
        regime_map["rho_cyc"].append(p["cycle"])
        regime_map["rho_transient"].append(p["transient"])

    return regime_map
