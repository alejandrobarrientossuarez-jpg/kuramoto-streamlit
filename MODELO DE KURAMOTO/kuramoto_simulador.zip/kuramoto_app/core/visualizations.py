"""
Módulo de visualizaciones con Plotly.
Produce todas las figuras requeridas por el paper.
"""

import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import networkx as nx
from typing import List, Dict, Optional
import math


# ── Paleta de colores ────────────────────────────────────────────────────────
SYNC_COLOR   = "#00e5a0"   # verde cian: sincronización
FIXED_COLOR  = "#f5a623"   # naranja: punto fijo
CYCLE_COLOR  = "#e040fb"   # violeta: ciclo
TRANS_COLOR  = "#4a9eff"   # azul: transitorio
BG_COLOR     = "#0d1117"
GRID_COLOR   = "#1e2530"
TEXT_COLOR   = "#c9d1d9"
ACCENT       = "#58a6ff"

ATTRACTOR_COLORS = {
    "sync":        SYNC_COLOR,
    "fixed_point": FIXED_COLOR,
    "cycle":       CYCLE_COLOR,
    "transient":   TRANS_COLOR,
}

BASE_LAYOUT = dict(
    paper_bgcolor=BG_COLOR,
    plot_bgcolor=BG_COLOR,
    font=dict(color=TEXT_COLOR, family="JetBrains Mono, monospace"),
    margin=dict(l=40, r=20, t=50, b=40),
)


def phase_colorscale(M: int):
    """Genera una escala de colores cíclica para M fases."""
    colors = px.colors.sample_colorscale("hsv", [i/M for i in range(M)] + [0])
    return [[i/M, c] for i, c in enumerate(colors[:-1])] + [[1.0, colors[0]]]


# ── 1. Evolución de fases (heatmap tiempo × vértice) ────────────────────────

def fig_phase_evolution(trajectory: List[np.ndarray], M: int, sync_time: int = -1) -> go.Figure:
    """Heatmap: eje X = tiempo, eje Y = vértice, color = fase."""
    matrix = np.array(trajectory).T  # shape: (N, T)
    N, T = matrix.shape

    fig = go.Figure(go.Heatmap(
        z=matrix,
        x=list(range(T)),
        y=[f"v{i}" for i in range(N)],
        colorscale="HSV",
        zmin=0, zmax=M - 1,
        colorbar=dict(title="Fase", tickvals=list(range(M))),
        hoverongaps=False,
    ))

    if sync_time > 0:
        fig.add_vline(
            x=sync_time, line_dash="dash",
            line_color=SYNC_COLOR, line_width=2,
            annotation_text=f"sync t={sync_time}",
            annotation_font_color=SYNC_COLOR,
        )

    fig.update_layout(
        **BASE_LAYOUT,
        title="Evolución de fases θ_i(t)",
        xaxis_title="Tiempo t",
        yaxis_title="Vértice",
    )
    return fig


# ── 2. Medida de sincronización r(t) ─────────────────────────────────────────

def fig_sync_measure(sync_measures: List[float], attractor_type: str) -> go.Figure:
    T = list(range(len(sync_measures)))
    color = ATTRACTOR_COLORS.get(attractor_type, ACCENT)

    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=T, y=sync_measures,
        mode="lines+markers",
        line=dict(color=color, width=2),
        marker=dict(size=4),
        name="r(t)",
        fill="tozeroy",
        fillcolor=color.replace(")", ",0.12)").replace("rgb", "rgba"),
    ))
    fig.add_hline(y=1.0, line_dash="dot", line_color=SYNC_COLOR,
                  annotation_text="r=1 (sync)", annotation_font_color=SYNC_COLOR)

    fig.update_layout(
        **BASE_LAYOUT,
        title=f"Parámetro de orden r(t) — Atractor: <b>{attractor_type}</b>",
        xaxis_title="Tiempo t",
        yaxis_title="r(t)",
        yaxis=dict(range=[0, 1.05]),
    )
    return fig


# ── 3. Grafo dinámico (nodos coloreados por fase) ────────────────────────────

def fig_dynamic_graph(
    theta: np.ndarray,
    G: nx.Graph,
    M: int,
    epsilon: float = 0.0,
    title: str = "Estado del grafo"
) -> go.Figure:
    """Visualiza el grafo con nodos coloreados por fase y aristas sincronizadas resaltadas."""
    from core.dynamics import circular_distance

    pos = nx.spring_layout(G, seed=42)

    # Aristas
    edge_traces = []
    for (i, j) in G.edges():
        x0, y0 = pos[i]
        x1, y1 = pos[j]
        synced = circular_distance(theta[i], theta[j], M) <= epsilon
        color = SYNC_COLOR if synced else "#2d3748"
        width = 3 if synced else 1
        edge_traces.append(go.Scatter(
            x=[x0, x1, None], y=[y0, y1, None],
            mode="lines",
            line=dict(color=color, width=width),
            hoverinfo="none",
            showlegend=False,
        ))

    # Nodos
    node_x = [pos[i][0] for i in G.nodes()]
    node_y = [pos[i][1] for i in G.nodes()]
    node_colors = [theta[i] for i in G.nodes()]
    node_text = [f"v{i}: θ={theta[i]}" for i in G.nodes()]

    node_trace = go.Scatter(
        x=node_x, y=node_y,
        mode="markers+text",
        text=[f"v{i}" for i in G.nodes()],
        textposition="top center",
        marker=dict(
            size=28,
            color=node_colors,
            colorscale="HSV",
            cmin=0, cmax=M - 1,
            colorbar=dict(title="Fase"),
            line=dict(color=TEXT_COLOR, width=1.5),
        ),
        hovertext=node_text,
        hoverinfo="text",
    )

    fig = go.Figure(data=edge_traces + [node_trace])
    fig.update_layout(
        **BASE_LAYOUT,
        title=title,
        showlegend=False,
        xaxis=dict(showgrid=False, zeroline=False, visible=False),
        yaxis=dict(showgrid=False, zeroline=False, visible=False),
    )
    return fig


# ── 4. Diagrama de transiciones (grafo dirigido de subredes) ─────────────────

def fig_transition_diagram(trans_data: Dict, max_nodes: int = 40) -> go.Figure:
    """Visualiza el diagrama de transiciones como grafo dirigido."""
    trans_graph: nx.DiGraph = trans_data["trans_graph"]
    labels = trans_data["labels"]
    subnet_types = trans_data["subnet_types"]
    full_id = trans_data["full_sync_id"]

    if trans_graph.number_of_nodes() == 0:
        fig = go.Figure()
        fig.update_layout(**BASE_LAYOUT, title="Sin transiciones registradas")
        return fig

    # Limitar tamaño
    nodes_to_show = list(trans_graph.nodes())[:max_nodes]
    subg = trans_graph.subgraph(nodes_to_show)

    pos = nx.spring_layout(subg, seed=42, k=2)

    # Aristas con flechas
    edge_x, edge_y = [], []
    for (u, v) in subg.edges():
        x0, y0 = pos[u]
        x1, y1 = pos[v]
        edge_x += [x0, x1, None]
        edge_y += [y0, y1, None]

    edge_trace = go.Scatter(
        x=edge_x, y=edge_y,
        mode="lines",
        line=dict(color="#3a4a60", width=1.5),
        hoverinfo="none",
        showlegend=False,
    )

    # Nodos coloreados por tipo
    node_x = [pos[n][0] for n in subg.nodes()]
    node_y = [pos[n][1] for n in subg.nodes()]
    node_colors = [
        SYNC_COLOR if n == full_id
        else FIXED_COLOR if subnet_types.get(n) == "fixed"
        else ACCENT
        for n in subg.nodes()
    ]
    node_labels = [labels.get(n, f"S{n}") for n in subg.nodes()]

    node_trace = go.Scatter(
        x=node_x, y=node_y,
        mode="markers+text",
        text=[f"S{n}" for n in subg.nodes()],
        textposition="top center",
        marker=dict(
            size=18,
            color=node_colors,
            line=dict(color=TEXT_COLOR, width=1),
        ),
        hovertext=node_labels,
        hoverinfo="text",
    )

    fig = go.Figure(data=[edge_trace, node_trace])
    fig.update_layout(
        **BASE_LAYOUT,
        title=f"Diagrama de transiciones — {len(subg.nodes())} subredes realizables",
        showlegend=False,
        xaxis=dict(showgrid=False, zeroline=False, visible=False),
        yaxis=dict(showgrid=False, zeroline=False, visible=False),
    )
    return fig


# ── 5. Mapa de regímenes ρ(κ) ────────────────────────────────────────────────

def fig_regime_map(regime_data: Dict) -> go.Figure:
    """Mapa de regímenes: proporciones de sincronización, puntos fijos y ciclos vs κ."""
    kappas = regime_data["kappa"]
    fig = go.Figure()

    traces = [
        ("ρ_sync", "rho_sync",   SYNC_COLOR),
        ("ρ_fix",  "rho_fix",    FIXED_COLOR),
        ("ρ_cyc",  "rho_cyc",    CYCLE_COLOR),
        ("ρ_trans","rho_transient", TRANS_COLOR),
    ]

    for name, key, color in traces:
        fig.add_trace(go.Scatter(
            x=kappas,
            y=regime_data[key],
            mode="lines+markers",
            name=name,
            line=dict(color=color, width=2.5),
            marker=dict(size=6),
            fill="tozeroy" if name == "ρ_sync" else None,
            fillcolor=f"rgba(0,229,160,0.08)" if name == "ρ_sync" else None,
        ))

    fig.update_layout(
        **BASE_LAYOUT,
        title="Mapa de regímenes dinámicos ρ(κ)",
        xaxis_title="Umbral κ",
        yaxis_title="Proporción",
        yaxis=dict(range=[0, 1.05]),
        legend=dict(bgcolor="rgba(0,0,0,0.4)"),
    )
    return fig


# ── 6. Tabla de trayectoria ───────────────────────────────────────────────────

def table_trajectory(trajectory, S_traj, sigma_traj, N) -> go.Figure:
    """Tabla interactiva con θ_t, S_i y σ_κ(S_i) para cada tiempo."""
    t_vals = list(range(len(trajectory)))
    rows_theta  = [f"[{','.join(str(x) for x in traj)}]" for traj in trajectory]

    S_str = ["—"] + [f"[{','.join(str(s) for s in sv)}]" for sv in S_traj]
    sig_str = ["—"] + [f"[{','.join(str(s) for s in sv)}]" for sv in sigma_traj]

    fig = go.Figure(go.Table(
        header=dict(
            values=["<b>t</b>", "<b>θ_t</b>", "<b>S_i(θ)</b>", "<b>σ_κ(S_i)</b>"],
            fill_color="#1a2332",
            font=dict(color=ACCENT, size=13),
            align="center",
            height=32,
        ),
        cells=dict(
            values=[t_vals, rows_theta, S_str, sig_str],
            fill_color=BG_COLOR,
            font=dict(color=TEXT_COLOR, size=12),
            align="center",
            height=28,
        ),
    ))
    fig.update_layout(
        **BASE_LAYOUT,
        title="Trayectoria completa",
        margin=dict(l=10, r=10, t=40, b=10),
    )
    return fig


# ── 7. Distribución de tiempos de sincronización ─────────────────────────────

def fig_sync_time_hist(sync_times: List[int]) -> go.Figure:
    if not sync_times:
        fig = go.Figure()
        fig.update_layout(**BASE_LAYOUT, title="Sin sincronizaciones detectadas")
        return fig

    fig = go.Figure(go.Histogram(
        x=sync_times,
        marker_color=SYNC_COLOR,
        opacity=0.85,
        nbinsx=min(30, max(sync_times) - min(sync_times) + 1),
    ))
    fig.update_layout(
        **BASE_LAYOUT,
        title="Distribución de tiempos de sincronización",
        xaxis_title="Tiempo de sincronización",
        yaxis_title="Frecuencia",
    )
    return fig
