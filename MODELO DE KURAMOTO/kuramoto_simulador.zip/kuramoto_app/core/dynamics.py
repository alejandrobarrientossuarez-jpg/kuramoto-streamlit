"""
Motor de dinámica discreta de Kuramoto con umbral.

Regla de actualización:
  (F_k(θ))_i = θ_i + ω* + σ_κ(S_i(θ))   (mod M)

donde:
  S_i(θ) = Σ_{j∈N(i)} d_M(θ_j, θ_i)
  d_M(a,b) = min(|a-b|, M-|a-b|)   (distancia circular)
  σ_κ(s) = +1 si s > κ, -1 si s < -κ, 0 si |s| ≤ κ
"""

import numpy as np
from typing import List, Tuple, Dict, Optional
import networkx as nx


def circular_distance(a: int, b: int, M: int) -> int:
    """Distancia circular entre fases a y b en Z_M."""
    diff = abs(int(a) - int(b)) % M
    return min(diff, M - diff)


def signed_circular_distance(a: int, b: int, M: int) -> int:
    """Distancia circular con signo: positivo si b está 'adelante' de a en Z_M."""
    diff = (int(b) - int(a)) % M
    if diff <= M // 2:
        return diff
    else:
        return diff - M


def coupling_sum(theta: np.ndarray, i: int, neighbors: List[int], M: int) -> int:
    """
    S_i(θ) = Σ_{j∈N(i)} d_M^signed(θ_i, θ_j)
    Suma de distancias con signo: atracción hacia la mayoría.
    """
    s = 0
    for j in neighbors:
        s += signed_circular_distance(theta[i], theta[j], M)
    return s


def sigma_kappa(s: int, kappa: float) -> int:
    """
    Función umbral σ_κ:
      +1 si s > κ
      -1 si s < -κ
       0 si |s| ≤ κ
    """
    if s > kappa:
        return 1
    elif s < -kappa:
        return -1
    else:
        return 0


def step(theta: np.ndarray, adjacency: dict, omega: int, kappa: float, M: int) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Un paso de la dinámica: actualización simultánea de todos los vértices.
    
    Returns:
        theta_new: nuevo estado
        S_values: valores de S_i para cada vértice
        sigma_values: valores de σ_κ(S_i) para cada vértice
    """
    N = len(theta)
    S_values = np.zeros(N, dtype=int)
    sigma_values = np.zeros(N, dtype=int)
    theta_new = np.zeros(N, dtype=int)

    for i in range(N):
        neighbors = adjacency.get(i, [])
        S_i = coupling_sum(theta, i, neighbors, M)
        sig = sigma_kappa(S_i, kappa)
        S_values[i] = S_i
        sigma_values[i] = sig
        theta_new[i] = (theta[i] + omega + sig) % M

    return theta_new, S_values, sigma_values


def is_synchronized(theta: np.ndarray) -> bool:
    """Verifica si todas las fases son iguales."""
    return bool(np.all(theta == theta[0]))


def synchronization_measure(theta: np.ndarray, M: int) -> float:
    """
    Medida de sincronización en [0,1]:
    1.0 = completamente sincronizado, 0.0 = completamente disperso.
    Usa el orden de Kuramoto discreto (proyección en círculo).
    """
    phases = 2 * np.pi * theta / M
    r = abs(np.mean(np.exp(1j * phases)))
    return float(r)


def run_simulation(
    theta0: np.ndarray,
    adjacency: dict,
    omega: int,
    kappa: float,
    M: int,
    max_steps: int = 200,
    epsilon: float = 0.0
) -> Dict:
    """
    Ejecuta la simulación completa desde una condición inicial.
    
    Returns dict con:
        trajectory: lista de arrays θ_t
        S_trajectory: lista de arrays S_i(θ_t)
        sigma_trajectory: lista de arrays σ_κ(S_i)
        sync_measures: medida de sincronización en cada t
        attractor_type: 'sync', 'fixed_point', 'cycle', 'transient'
        cycle_length: longitud del ciclo detectado (0 si no hay)
        sync_time: tiempo de sincronización (-1 si no sincroniza)
        final_state: estado final
    """
    theta = theta0.copy()
    trajectory = [theta.copy()]
    S_traj = []
    sigma_traj = []
    sync_measures = [synchronization_measure(theta, M)]

    # Para detección de ciclos: guardamos estados como tuplas
    seen_states = {tuple(theta): 0}
    sync_time = -1
    attractor_type = "transient"
    cycle_length = 0

    for t in range(1, max_steps + 1):
        theta_new, S_vals, sig_vals = step(theta, adjacency, omega, kappa, M)
        S_traj.append(S_vals.copy())
        sigma_traj.append(sig_vals.copy())
        theta = theta_new
        trajectory.append(theta.copy())
        sync_measures.append(synchronization_measure(theta, M))

        # Detectar sincronización
        if is_synchronized(theta) and sync_time == -1:
            sync_time = t
            attractor_type = "sync"

        # Detectar ciclo o punto fijo
        state_key = tuple(theta)
        if state_key in seen_states:
            prev_t = seen_states[state_key]
            cycle_length = t - prev_t
            if cycle_length == 1:
                if attractor_type != "sync":
                    attractor_type = "fixed_point"
            else:
                if attractor_type != "sync":
                    attractor_type = "cycle"
            break
        seen_states[state_key] = t

    # Si llegamos al máximo sin detectar nada
    if attractor_type == "transient":
        attractor_type = "transient"

    return {
        "trajectory": trajectory,
        "S_trajectory": S_traj,
        "sigma_trajectory": sigma_traj,
        "sync_measures": sync_measures,
        "attractor_type": attractor_type,
        "cycle_length": cycle_length,
        "sync_time": sync_time,
        "final_state": theta.copy(),
        "steps_run": len(trajectory) - 1,
    }
