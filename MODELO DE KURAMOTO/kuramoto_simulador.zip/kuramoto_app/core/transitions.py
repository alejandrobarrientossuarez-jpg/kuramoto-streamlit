"""
Módulo 3: Diagrama de transiciones y subredes de acuerdo.

Para cada configuración θ_t define la subred de acuerdo:
  G^ε_{θ_t} = (V, E^ε_{θ_t})
donde (i,j) ∈ E^ε ssi d_M(θ_i, θ_j) ≤ ε

El diagrama de transiciones es el grafo dirigido cuyas:
  - Nodos = subredes de acuerdo observadas
  - Aristas = transiciones θ_t → θ_{t+1}
"""

import numpy as np
import networkx as nx
from typing import List, Dict, Tuple, Set, FrozenSet
from core.dynamics import circular_distance


def agreement_subnetwork(
    theta: np.ndarray,
    base_graph: nx.Graph,
    M: int,
    epsilon: float = 0.0
) -> FrozenSet[Tuple[int,int]]:
    """
    Calcula la subred de acuerdo G^ε_θ.
    Retorna el conjunto de aristas (como frozenset para usarlo como llave).
    
    Sólo considera aristas que existen en el grafo base.
    """
    edges = set()
    for (i, j) in base_graph.edges():
        if circular_distance(theta[i], theta[j], M) <= epsilon:
            e = (min(i,j), max(i,j))
            edges.add(e)
    return frozenset(edges)


def edges_to_partition(edge_set: FrozenSet, N: int) -> FrozenSet[FrozenSet[int]]:
    """
    Convierte un conjunto de aristas a la partición de vértices
    que define (componentes conexas de la subred de acuerdo).
    """
    G = nx.Graph()
    G.add_nodes_from(range(N))
    G.add_edges_from(edge_set)
    components = [frozenset(c) for c in nx.connected_components(G)]
    return frozenset(components)


def build_transition_diagram(
    trajectory: List[np.ndarray],
    base_graph: nx.Graph,
    M: int,
    epsilon: float = 0.0
) -> Dict:
    """
    Construye el diagrama de transiciones a partir de una trayectoria.
    
    Returns:
        nodes: dict {subnetwork_id -> (edge_frozenset, partition)}
        transitions: lista de (from_id, to_id, time)
        paths_to_sync: caminos que terminan en grafo completo
        paths_to_cycle: caminos que terminan en ciclo
        realizable_count: número de subredes realizadas
        subnetwork_labels: etiquetas legibles para cada subred
    """
    N = base_graph.number_of_nodes()

    # Mapa de subredes observadas: frozenset(edges) -> id
    subnet_map = {}
    subnet_id_counter = [0]

    def get_subnet_id(edge_fs):
        if edge_fs not in subnet_map:
            subnet_map[edge_fs] = subnet_id_counter[0]
            subnet_id_counter[0] += 1
        return subnet_map[edge_fs]

    transitions = []
    subnet_sequence = []

    for theta in trajectory:
        ef = agreement_subnetwork(theta, base_graph, M, epsilon)
        sid = get_subnet_id(ef)
        subnet_sequence.append(sid)

    for t in range(len(subnet_sequence) - 1):
        transitions.append((subnet_sequence[t], subnet_sequence[t+1], t))

    # Identificar tipo de cada subred
    full_edges = frozenset((min(i,j), max(i,j)) for (i,j) in base_graph.edges())
    empty_edges = frozenset()

    subnet_types = {}
    for ef, sid in subnet_map.items():
        if ef == full_edges:
            subnet_types[sid] = "sync"
        elif ef == empty_edges:
            subnet_types[sid] = "empty"
        else:
            subnet_types[sid] = "partial"

    # Construir grafo de transiciones
    trans_graph = nx.DiGraph()
    for (src, dst, t) in transitions:
        if not trans_graph.has_edge(src, dst):
            trans_graph.add_edge(src, dst, times=[t])
        else:
            trans_graph[src][dst]["times"].append(t)

    # Generar etiquetas legibles
    labels = {}
    for ef, sid in subnet_map.items():
        partition = edges_to_partition(ef, N)
        parts_str = "|".join(
            "{" + ",".join(str(v) for v in sorted(p)) + "}"
            for p in sorted(partition, key=lambda x: min(x))
        )
        labels[sid] = f"S{sid}: {parts_str}"

    return {
        "subnet_map": {str(list(k)): v for k, v in subnet_map.items()},
        "subnet_sequence": subnet_sequence,
        "transitions": transitions,
        "trans_graph": trans_graph,
        "subnet_types": subnet_types,
        "labels": labels,
        "realizable_count": len(subnet_map),
        "full_sync_id": subnet_map.get(full_edges, None),
        "empty_id": subnet_map.get(empty_edges, None),
        "N": N,
        "epsilon": epsilon,
    }


def aggregate_transition_diagram(
    all_trajectories: List[List[np.ndarray]],
    base_graph: nx.Graph,
    M: int,
    epsilon: float = 0.0
) -> Dict:
    """
    Construye el diagrama de transiciones agregado sobre TODAS las trayectorias.
    Útil para exploración exhaustiva.
    """
    N = base_graph.number_of_nodes()
    subnet_map = {}
    subnet_id_counter = [0]
    transition_counts = {}

    def get_subnet_id(edge_fs):
        if edge_fs not in subnet_map:
            subnet_map[edge_fs] = subnet_id_counter[0]
            subnet_id_counter[0] += 1
        return subnet_map[edge_fs]

    for traj in all_trajectories:
        prev_sid = None
        for theta in traj:
            ef = agreement_subnetwork(theta, base_graph, M, epsilon)
            sid = get_subnet_id(ef)
            if prev_sid is not None and prev_sid != sid:
                key = (prev_sid, sid)
                transition_counts[key] = transition_counts.get(key, 0) + 1
            prev_sid = sid

    full_edges = frozenset((min(i,j), max(i,j)) for (i,j) in base_graph.edges())
    labels = {}
    for ef, sid in subnet_map.items():
        partition = edges_to_partition(ef, N)
        parts_str = "|".join(
            "{" + ",".join(str(v) for v in sorted(p)) + "}"
            for p in sorted(partition, key=lambda x: min(x))
        )
        labels[sid] = parts_str

    return {
        "subnet_map": subnet_map,
        "transition_counts": transition_counts,
        "labels": labels,
        "realizable_count": len(subnet_map),
        "full_sync_id": subnet_map.get(full_edges, None),
        "N": N,
    }
