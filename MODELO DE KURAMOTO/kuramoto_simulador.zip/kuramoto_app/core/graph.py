"""
Módulo de grafos para el simulador de Kuramoto discreto.
Soporta: Completo K_N, Camino P_N, Ciclo C_N, Estrella, Personalizado.
"""

import numpy as np
import networkx as nx
from typing import List, Tuple, Optional


def build_graph(graph_type: str, N: int, custom_edges: Optional[List[Tuple[int,int]]] = None) -> nx.Graph:
    """Construye el grafo según el tipo especificado."""
    if graph_type == "completo":
        G = nx.complete_graph(N)
    elif graph_type == "camino":
        G = nx.path_graph(N)
    elif graph_type == "ciclo":
        G = nx.cycle_graph(N)
    elif graph_type == "estrella":
        G = nx.star_graph(N - 1)
    elif graph_type == "personalizado" and custom_edges is not None:
        G = nx.Graph()
        G.add_nodes_from(range(N))
        G.add_edges_from(custom_edges)
    else:
        G = nx.complete_graph(N)
    return G


def adjacency_list(G: nx.Graph) -> dict:
    """Retorna diccionario de vecinos para cada nodo."""
    return {i: list(G.neighbors(i)) for i in G.nodes()}


def graph_info(G: nx.Graph) -> dict:
    """Información básica del grafo."""
    return {
        "nodes": G.number_of_nodes(),
        "edges": G.number_of_edges(),
        "degrees": dict(G.degree()),
        "is_connected": nx.is_connected(G),
    }
