"""
Simulador de Sincronización Discreta tipo Kuramoto sobre Grafos
Aplicación principal — Dash by Plotly
Para deployment en Render.com
"""

import dash
from dash import dcc, html, Input, Output, State, callback_context, no_update
import dash_bootstrap_components as dbc
import numpy as np
import json
import plotly.graph_objects as go

from core.graph import build_graph, adjacency_list, graph_info
from core.dynamics import run_simulation
from core.exploration import explore_exhaustive, sweep_kappa, bell_number
from core.transitions import build_transition_diagram
from core.visualizations import (
    fig_phase_evolution, fig_sync_measure, fig_dynamic_graph,
    fig_transition_diagram, fig_regime_map, table_trajectory,
    fig_sync_time_hist, BG_COLOR, TEXT_COLOR, ACCENT, BASE_LAYOUT,
    ATTRACTOR_COLORS,
)

# ── Estilos globales ──────────────────────────────────────────────────────────
DARK = "#0d1117"
CARD = "#161b22"
BORDER = "#21262d"
ACCENT2 = "#00e5a0"

CARD_STYLE = {
    "backgroundColor": CARD,
    "border": f"1px solid {BORDER}",
    "borderRadius": "10px",
    "padding": "18px",
    "marginBottom": "16px",
}

LABEL_STYLE = {
    "color": "#8b949e",
    "fontSize": "11px",
    "fontFamily": "JetBrains Mono, monospace",
    "letterSpacing": "0.08em",
    "textTransform": "uppercase",
    "marginBottom": "6px",
}

INPUT_STYLE = {
    "backgroundColor": "#0d1117",
    "border": f"1px solid {BORDER}",
    "borderRadius": "6px",
    "color": TEXT_COLOR,
    "fontFamily": "JetBrains Mono, monospace",
}

SLIDER_MARKS_STYLE = {"color": "#8b949e", "fontSize": "10px"}


# ── App Dash ──────────────────────────────────────────────────────────────────
app = dash.Dash(
    __name__,
    external_stylesheets=[
        dbc.themes.BOOTSTRAP,
        "https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@300;400;600&family=Space+Grotesk:wght@400;600;700&display=swap",
    ],
    title="Kuramoto Discreto",
    suppress_callback_exceptions=True,
)
server = app.server  # Necesario para Render / gunicorn


# ── Layout ────────────────────────────────────────────────────────────────────
def make_slider(id, min_val, max_val, step, value, marks=None):
    return dcc.Slider(
        id=id, min=min_val, max=max_val, step=step, value=value,
        marks=marks or {v: {"label": str(v), "style": SLIDER_MARKS_STYLE}
                        for v in np.linspace(min_val, max_val, 6, dtype=float).tolist()},
        tooltip={"placement": "bottom", "always_visible": False},
        className="kuramoto-slider",
    )


def sidebar():
    return html.Div([

        # Header
        html.Div([
            html.Div("κ", style={"fontSize": "2.4rem", "color": ACCENT2, "fontFamily": "Space Grotesk", "fontWeight": "700", "lineHeight": "1"}),
            html.Div([
                html.Span("KURAMOTO", style={"color": TEXT_COLOR, "fontSize": "1rem", "fontWeight": "600", "fontFamily": "Space Grotesk", "letterSpacing": "0.15em"}),
                html.Br(),
                html.Span("DISCRETO", style={"color": ACCENT, "fontSize": "0.8rem", "fontFamily": "JetBrains Mono", "letterSpacing": "0.2em"}),
            ], style={"marginLeft": "12px"}),
        ], style={"display": "flex", "alignItems": "center", "marginBottom": "28px"}),

        # Tipo de grafo
        html.Div([
            html.Div("GRAFO", style=LABEL_STYLE),
            dcc.Dropdown(
                id="graph-type",
                options=[
                    {"label": "Completo K_N",  "value": "completo"},
                    {"label": "Camino P_N",    "value": "camino"},
                    {"label": "Ciclo C_N",     "value": "ciclo"},
                    {"label": "Estrella",      "value": "estrella"},
                ],
                value="completo",
                clearable=False,
                style={**INPUT_STYLE, "color": "#000"},
            ),
            html.Div(id="graph-info-text", style={"color": "#8b949e", "fontSize": "11px", "marginTop": "6px", "fontFamily": "JetBrains Mono"}),
        ], style=CARD_STYLE),

        # Parámetros
        html.Div([
            html.Div("PARÁMETROS", style=LABEL_STYLE),

            html.Div("N — Vértices", style={**LABEL_STYLE, "marginTop": "10px"}),
            make_slider("param-N", 2, 8, 1, 4,
                        marks={i: {"label": str(i), "style": SLIDER_MARKS_STYLE} for i in range(2, 9)}),

            html.Div("M — Fases discretas", style={**LABEL_STYLE, "marginTop": "14px"}),
            make_slider("param-M", 2, 12, 1, 6,
                        marks={i: {"label": str(i), "style": SLIDER_MARKS_STYLE} for i in [2,3,4,5,6,8,10,12]}),

            html.Div("κ — Umbral de acoplamiento", style={**LABEL_STYLE, "marginTop": "14px"}),
            make_slider("param-kappa", 0, 20, 0.5, 2.0,
                        marks={i: {"label": str(i), "style": SLIDER_MARKS_STYLE} for i in range(0, 21, 4)}),

            html.Div("ω* — Frecuencia natural", style={**LABEL_STYLE, "marginTop": "14px"}),
            make_slider("param-omega", 0, 5, 1, 0,
                        marks={i: {"label": str(i), "style": SLIDER_MARKS_STYLE} for i in range(6)}),

            html.Div("ε — Precisión de sincronización", style={**LABEL_STYLE, "marginTop": "14px"}),
            make_slider("param-epsilon", 0, 3, 1, 0,
                        marks={i: {"label": str(i), "style": SLIDER_MARKS_STYLE} for i in range(4)}),

            html.Div("Pasos máximos", style={**LABEL_STYLE, "marginTop": "14px"}),
            make_slider("param-maxsteps", 10, 500, 10, 100,
                        marks={i: {"label": str(i), "style": SLIDER_MARKS_STYLE} for i in [10,50,100,200,500]}),

        ], style=CARD_STYLE),

        # Condición inicial
        html.Div([
            html.Div("CONDICIÓN INICIAL", style=LABEL_STYLE),
            dcc.RadioItems(
                id="ic-type",
                options=[
                    {"label": " Aleatoria", "value": "random"},
                    {"label": " Manual",    "value": "manual"},
                ],
                value="random",
                labelStyle={"display": "block", "color": TEXT_COLOR, "marginBottom": "6px", "cursor": "pointer", "fontFamily": "JetBrains Mono", "fontSize": "13px"},
            ),
            html.Div(id="manual-ic-container", style={"marginTop": "10px"}),
            dbc.Button("↻  Nueva aleatoria", id="btn-new-random", color="secondary", size="sm",
                       style={"width": "100%", "marginTop": "10px", "fontFamily": "JetBrains Mono",
                              "backgroundColor": "#1a2332", "border": f"1px solid {BORDER}", "color": ACCENT}),
        ], style=CARD_STYLE),

    ], style={
        "width": "290px", "minWidth": "290px",
        "backgroundColor": "#0a0f16",
        "borderRight": f"1px solid {BORDER}",
        "padding": "24px 16px",
        "overflowY": "auto",
        "height": "100vh",
        "position": "sticky",
        "top": "0",
    })


def main_content():
    return html.Div([

        # Tabs
        dcc.Tabs(id="main-tabs", value="tab-sim", style={"borderBottom": f"1px solid {BORDER}"},
                 children=[
                     dcc.Tab(label="① Simulación", value="tab-sim",
                             style={"backgroundColor": DARK, "color": "#8b949e", "border": "none", "fontFamily": "Space Grotesk"},
                             selected_style={"backgroundColor": CARD, "color": ACCENT2, "border": f"1px solid {BORDER}", "borderBottom": f"2px solid {ACCENT2}", "fontFamily": "Space Grotesk"}),
                     dcc.Tab(label="② Exploración", value="tab-explore",
                             style={"backgroundColor": DARK, "color": "#8b949e", "border": "none", "fontFamily": "Space Grotesk"},
                             selected_style={"backgroundColor": CARD, "color": ACCENT2, "border": f"1px solid {BORDER}", "borderBottom": f"2px solid {ACCENT2}", "fontFamily": "Space Grotesk"}),
                     dcc.Tab(label="③ Diagrama de Transiciones", value="tab-trans",
                             style={"backgroundColor": DARK, "color": "#8b949e", "border": "none", "fontFamily": "Space Grotesk"},
                             selected_style={"backgroundColor": CARD, "color": ACCENT2, "border": f"1px solid {BORDER}", "borderBottom": f"2px solid {ACCENT2}", "fontFamily": "Space Grotesk"}),
                     dcc.Tab(label="④ Mapa de Regímenes", value="tab-regime",
                             style={"backgroundColor": DARK, "color": "#8b949e", "border": "none", "fontFamily": "Space Grotesk"},
                             selected_style={"backgroundColor": CARD, "color": ACCENT2, "border": f"1px solid {BORDER}", "borderBottom": f"2px solid {ACCENT2}", "fontFamily": "Space Grotesk"}),
                 ]),

        html.Div(id="tab-content", style={"padding": "20px", "minHeight": "calc(100vh - 50px)"}),

        # Store para estado compartido
        dcc.Store(id="sim-result-store"),
        dcc.Store(id="explore-result-store"),
        dcc.Store(id="random-seed-store", data=42),
    ])


app.layout = html.Div([
    html.Div([sidebar(), main_content()], style={"display": "flex", "height": "100vh", "overflow": "hidden"}),
], style={"backgroundColor": DARK, "minHeight": "100vh"})


# ── CSS global ────────────────────────────────────────────────────────────────
app.index_string = '''
<!DOCTYPE html>
<html>
    <head>
        {%metas%}
        <title>{%title%}</title>
        {%favicon%}
        {%css%}
        <style>
            body { margin: 0; background: #0d1117; }
            ::-webkit-scrollbar { width: 6px; }
            ::-webkit-scrollbar-track { background: #0d1117; }
            ::-webkit-scrollbar-thumb { background: #21262d; border-radius: 3px; }
            .kuramoto-slider .rc-slider-rail { background: #21262d; }
            .kuramoto-slider .rc-slider-track { background: #58a6ff; }
            .kuramoto-slider .rc-slider-handle { background: #58a6ff; border-color: #58a6ff; }
            .Select-control { background-color: #161b22 !important; border-color: #21262d !important; }
            .Select-menu-outer { background-color: #161b22 !important; }
            .VirtualizedSelectOption { color: #c9d1d9 !important; }
            .Select-value-label { color: #c9d1d9 !important; }
            .Select-placeholder { color: #8b949e !important; }
            .dash-table-container .dash-spreadsheet-container .dash-spreadsheet-inner input { background: #0d1117 !important; color: #c9d1d9 !important; }
        </style>
    </head>
    <body>
        {%app_entry%}
        <footer>
            {%config%}
            {%scripts%}
            {%renderer%}
        </footer>
    </body>
</html>
'''


# ── Helpers ───────────────────────────────────────────────────────────────────

def get_graph_and_adjacency(graph_type, N):
    G = build_graph(graph_type, N)
    adj = adjacency_list(G)
    return G, adj


def attractor_badge(att_type: str) -> html.Span:
    colors = {"sync": ACCENT2, "fixed_point": "#f5a623", "cycle": "#e040fb", "transient": "#4a9eff"}
    labels = {"sync": "✓ SINCRONIZADO", "fixed_point": "● PUNTO FIJO", "cycle": "↻ CICLO", "transient": "~ TRANSITORIO"}
    c = colors.get(att_type, "#8b949e")
    return html.Span(
        labels.get(att_type, att_type.upper()),
        style={"backgroundColor": f"{c}22", "border": f"1px solid {c}",
               "color": c, "padding": "3px 10px", "borderRadius": "20px",
               "fontSize": "11px", "fontFamily": "JetBrains Mono", "fontWeight": "600",
               "letterSpacing": "0.08em"},
    )


# ── Callbacks ─────────────────────────────────────────────────────────────────

# Mostrar/ocultar input manual de condición inicial
@app.callback(
    Output("manual-ic-container", "children"),
    Input("ic-type", "value"),
    Input("param-N", "value"),
    Input("param-M", "value"),
)
def update_manual_ic_ui(ic_type, N, M):
    if ic_type != "manual":
        return []
    inputs = []
    for i in range(N):
        inputs.append(html.Div([
            html.Span(f"v{i}:", style={"color": "#8b949e", "width": "28px", "display": "inline-block", "fontFamily": "JetBrains Mono", "fontSize": "12px"}),
            dcc.Input(
                id={"type": "manual-ic", "index": i},
                type="number", min=0, max=M-1, step=1, value=0,
                style={**INPUT_STYLE, "width": "64px", "padding": "3px 6px", "fontSize": "13px"},
            ),
        ], style={"display": "flex", "alignItems": "center", "gap": "8px", "marginBottom": "4px"}))
    return inputs


# Info del grafo
@app.callback(
    Output("graph-info-text", "children"),
    Input("graph-type", "value"),
    Input("param-N", "value"),
)
def update_graph_info(graph_type, N):
    try:
        G, _ = get_graph_and_adjacency(graph_type, N)
        info = graph_info(G)
        return f"N={info['nodes']}  |E|={info['edges']}  conexo={info['is_connected']}"
    except Exception as e:
        return f"Error: {e}"


# Nuevo seed aleatorio
@app.callback(
    Output("random-seed-store", "data"),
    Input("btn-new-random", "n_clicks"),
    State("random-seed-store", "data"),
)
def new_random_seed(n_clicks, seed):
    if n_clicks:
        return int(np.random.randint(0, 99999))
    return seed


# Ejecutar simulación y guardar en store
@app.callback(
    Output("sim-result-store", "data"),
    Input("main-tabs", "value"),
    Input("param-N", "value"),
    Input("param-M", "value"),
    Input("param-kappa", "value"),
    Input("param-omega", "value"),
    Input("param-epsilon", "value"),
    Input("param-maxsteps", "value"),
    Input("graph-type", "value"),
    Input("ic-type", "value"),
    Input("random-seed-store", "data"),
    State({"type": "manual-ic", "index": dash.ALL}, "value"),
)
def run_sim(tab, N, M, kappa, omega, epsilon, max_steps, graph_type, ic_type, seed, manual_vals):
    if tab not in ("tab-sim", "tab-trans"):
        return no_update

    G, adj = get_graph_and_adjacency(graph_type, N)

    if ic_type == "manual" and manual_vals:
        theta0 = np.array([int(v or 0) % M for v in manual_vals[:N]], dtype=int)
    else:
        rng = np.random.default_rng(seed)
        theta0 = rng.integers(0, M, size=N)

    result = run_simulation(theta0, adj, int(omega), float(kappa), M, int(max_steps), float(epsilon))

    # Serializar para dcc.Store
    return {
        "theta0": theta0.tolist(),
        "trajectory": [t.tolist() for t in result["trajectory"]],
        "S_trajectory": [s.tolist() for s in result["S_trajectory"]],
        "sigma_trajectory": [s.tolist() for s in result["sigma_trajectory"]],
        "sync_measures": result["sync_measures"],
        "attractor_type": result["attractor_type"],
        "cycle_length": result["cycle_length"],
        "sync_time": result["sync_time"],
        "final_state": result["final_state"].tolist(),
        "steps_run": result["steps_run"],
        "N": N, "M": M, "kappa": kappa, "omega": omega,
        "epsilon": epsilon, "graph_type": graph_type,
    }


# Renderizar tab content
@app.callback(
    Output("tab-content", "children"),
    Input("main-tabs", "value"),
    Input("sim-result-store", "data"),
    State("param-N", "value"),
    State("param-M", "value"),
    State("param-kappa", "value"),
    State("param-omega", "value"),
    State("param-epsilon", "value"),
    State("param-maxsteps", "value"),
    State("graph-type", "value"),
)
def render_tab(tab, sim_data, N, M, kappa, omega, epsilon, max_steps, graph_type):

    # ── Tab 1: Simulación individual ─────────────────────────────────────────
    if tab == "tab-sim":
        if not sim_data:
            return html.Div("Ajusta los parámetros para iniciar la simulación.",
                            style={"color": "#8b949e", "fontFamily": "JetBrains Mono", "padding": "40px", "textAlign": "center"})

        traj = [np.array(t) for t in sim_data["trajectory"]]
        att = sim_data["attractor_type"]
        sync_t = sim_data["sync_time"]
        G, _ = get_graph_and_adjacency(sim_data["graph_type"], sim_data["N"])

        # Métricas
        metrics_row = html.Div([
            html.Div([
                html.Div("ATRACTOR", style=LABEL_STYLE),
                attractor_badge(att),
            ], style={**CARD_STYLE, "flex": "1", "textAlign": "center"}),
            html.Div([
                html.Div("TIEMPO SYNC", style=LABEL_STYLE),
                html.Div(str(sync_t) if sync_t >= 0 else "—",
                         style={"color": ACCENT2 if sync_t >= 0 else "#8b949e", "fontSize": "2rem",
                                "fontFamily": "Space Grotesk", "fontWeight": "700"}),
            ], style={**CARD_STYLE, "flex": "1", "textAlign": "center"}),
            html.Div([
                html.Div("PASOS", style=LABEL_STYLE),
                html.Div(str(sim_data["steps_run"]),
                         style={"color": ACCENT, "fontSize": "2rem", "fontFamily": "Space Grotesk", "fontWeight": "700"}),
            ], style={**CARD_STYLE, "flex": "1", "textAlign": "center"}),
            html.Div([
                html.Div("CICLO", style=LABEL_STYLE),
                html.Div(str(sim_data["cycle_length"]) if sim_data["cycle_length"] > 0 else "—",
                         style={"color": "#e040fb" if sim_data["cycle_length"] > 0 else "#8b949e",
                                "fontSize": "2rem", "fontFamily": "Space Grotesk", "fontWeight": "700"}),
            ], style={**CARD_STYLE, "flex": "1", "textAlign": "center"}),
        ], style={"display": "flex", "gap": "12px"})

        # Fila de grafos: animación del grafo en diferentes tiempos
        traj_len = len(traj)
        snap_indices = sorted(set([0, traj_len//4, traj_len//2, 3*traj_len//4, traj_len-1]))
        graph_snaps = html.Div([
            html.Div([
                html.Div(f"t = {ti}", style={**LABEL_STYLE, "textAlign": "center", "marginBottom": "4px"}),
                dcc.Graph(
                    figure=fig_dynamic_graph(traj[ti], G, sim_data["M"], sim_data["epsilon"],
                                             title=""),
                    config={"displayModeBar": False},
                    style={"height": "200px"},
                )
            ], style={**CARD_STYLE, "flex": "1", "padding": "10px"})
            for ti in snap_indices
        ], style={"display": "flex", "gap": "10px", "overflowX": "auto"})

        return html.Div([
            metrics_row,
            html.Div([
                html.Div([
                    dcc.Graph(
                        figure=fig_phase_evolution(traj, sim_data["M"], sync_t),
                        config={"displayModeBar": True},
                        style={"height": "320px"},
                    ),
                ], style={**CARD_STYLE, "flex": "1.5"}),
                html.Div([
                    dcc.Graph(
                        figure=fig_sync_measure(sim_data["sync_measures"], att),
                        config={"displayModeBar": False},
                        style={"height": "320px"},
                    ),
                ], style={**CARD_STYLE, "flex": "1"}),
            ], style={"display": "flex", "gap": "12px"}),

            html.Div("SNAPSHOTS DEL GRAFO", style={**LABEL_STYLE, "marginBottom": "8px"}),
            graph_snaps,

            html.Div("TRAYECTORIA COMPLETA", style={**LABEL_STYLE, "marginBottom": "8px", "marginTop": "8px"}),
            html.Div([
                dcc.Graph(
                    figure=table_trajectory(traj, sim_data["S_trajectory"], sim_data["sigma_trajectory"], sim_data["N"]),
                    config={"displayModeBar": False},
                    style={"height": "340px"},
                )
            ], style=CARD_STYLE),
        ])

    # ── Tab 2: Exploración exhaustiva ─────────────────────────────────────────
    elif tab == "tab-explore":
        total = M ** N
        warn = None
        if total > 1296:  # 6^4
            warn = html.Div(
                f"⚠  {M}^{N} = {total:,} configuraciones. Puede tardar. Reduce N o M para exploración rápida.",
                style={"backgroundColor": "#2d1b00", "border": "1px solid #f5a62366",
                       "borderRadius": "8px", "padding": "10px 14px",
                       "color": "#f5a623", "fontFamily": "JetBrains Mono", "fontSize": "12px",
                       "marginBottom": "12px"}
            )

        return html.Div([
            warn or html.Div(),
            html.Div([
                html.Div([
                    html.Div("N", style=LABEL_STYLE),
                    html.Div(str(N), style={"color": ACCENT, "fontSize": "1.8rem", "fontFamily": "Space Grotesk", "fontWeight": "700"}),
                ], style={**CARD_STYLE, "flex": "1", "textAlign": "center"}),
                html.Div([
                    html.Div("M", style=LABEL_STYLE),
                    html.Div(str(M), style={"color": ACCENT, "fontSize": "1.8rem", "fontFamily": "Space Grotesk", "fontWeight": "700"}),
                ], style={**CARD_STYLE, "flex": "1", "textAlign": "center"}),
                html.Div([
                    html.Div("M^N", style=LABEL_STYLE),
                    html.Div(f"{total:,}", style={"color": ACCENT2, "fontSize": "1.8rem", "fontFamily": "Space Grotesk", "fontWeight": "700"}),
                ], style={**CARD_STYLE, "flex": "1", "textAlign": "center"}),
                html.Div([
                    html.Div("B_N (Bell)", style=LABEL_STYLE),
                    html.Div(str(bell_number(N)), style={"color": "#e040fb", "fontSize": "1.8rem", "fontFamily": "Space Grotesk", "fontWeight": "700"}),
                ], style={**CARD_STYLE, "flex": "1", "textAlign": "center"}),
            ], style={"display": "flex", "gap": "12px", "marginBottom": "12px"}),

            dbc.Button(
                "▶  Ejecutar exploración exhaustiva",
                id="btn-explore",
                color="primary",
                style={"backgroundColor": "#0d2137", "border": f"1px solid {ACCENT}",
                       "color": ACCENT, "fontFamily": "Space Grotesk", "fontWeight": "600",
                       "width": "100%", "marginBottom": "16px", "padding": "12px"},
            ),
            html.Div(id="explore-results-container"),

            # κ sweep
            html.Hr(style={"borderColor": BORDER}),
            html.Div("MAPA DE REGÍMENES ρ(κ)", style={**LABEL_STYLE, "marginTop": "12px", "marginBottom": "8px"}),
            html.Div([
                html.Div("Rango de κ:", style={**LABEL_STYLE, "display": "inline-block"}),
                dcc.RangeSlider(
                    id="kappa-range-slider",
                    min=0, max=30, step=1, value=[0, 15],
                    marks={i: {"label": str(i), "style": SLIDER_MARKS_STYLE} for i in range(0, 31, 5)},
                    tooltip={"placement": "bottom"},
                ),
            ], style={"marginBottom": "12px"}),
            dbc.Button(
                "▶  Calcular mapa de regímenes",
                id="btn-regime",
                color="secondary",
                style={"backgroundColor": "#130d21", "border": f"1px solid #e040fb",
                       "color": "#e040fb", "fontFamily": "Space Grotesk", "fontWeight": "600",
                       "width": "100%", "marginBottom": "16px", "padding": "12px"},
            ),
            html.Div(id="regime-map-container"),
        ])

    # ── Tab 3: Diagrama de transiciones ──────────────────────────────────────
    elif tab == "tab-trans":
        if not sim_data:
            return html.Div("Ejecuta primero una simulación en la pestaña ①.",
                            style={"color": "#8b949e", "fontFamily": "JetBrains Mono", "padding": "40px", "textAlign": "center"})

        traj = [np.array(t) for t in sim_data["trajectory"]]
        G, _ = get_graph_and_adjacency(sim_data["graph_type"], sim_data["N"])
        trans_data = build_transition_diagram(traj, G, sim_data["M"], sim_data["epsilon"])

        # Leyenda de subredes
        labels_list = [
            html.Div(f"S{sid}: {lbl}",
                     style={"fontFamily": "JetBrains Mono", "fontSize": "11px",
                            "color": ACCENT2 if sid == trans_data["full_sync_id"] else TEXT_COLOR,
                            "marginBottom": "3px"})
            for sid, lbl in trans_data["labels"].items()
        ]

        return html.Div([
            html.Div([
                html.Div([
                    html.Div("SUBREDES REALIZABLES", style=LABEL_STYLE),
                    html.Div(str(trans_data["realizable_count"]),
                             style={"color": ACCENT, "fontSize": "2.4rem", "fontFamily": "Space Grotesk", "fontWeight": "700"}),
                ], style={**CARD_STYLE, "flex": "1", "textAlign": "center"}),
                html.Div([
                    html.Div("B_N (Bell)", style=LABEL_STYLE),
                    html.Div(str(bell_number(sim_data["N"])),
                             style={"color": "#e040fb", "fontSize": "2.4rem", "fontFamily": "Space Grotesk", "fontWeight": "700"}),
                    html.Div("particiones posibles", style={"color": "#8b949e", "fontSize": "10px", "fontFamily": "JetBrains Mono"}),
                ], style={**CARD_STYLE, "flex": "1", "textAlign": "center"}),
                html.Div([
                    html.Div("ε", style=LABEL_STYLE),
                    html.Div(str(sim_data["epsilon"]),
                             style={"color": ACCENT2, "fontSize": "2.4rem", "fontFamily": "Space Grotesk", "fontWeight": "700"}),
                ], style={**CARD_STYLE, "flex": "1", "textAlign": "center"}),
            ], style={"display": "flex", "gap": "12px"}),

            html.Div([
                html.Div([
                    dcc.Graph(
                        figure=fig_transition_diagram(trans_data),
                        config={"displayModeBar": True},
                        style={"height": "480px"},
                    )
                ], style={**CARD_STYLE, "flex": "2"}),
                html.Div([
                    html.Div("SUBREDES OBSERVADAS", style=LABEL_STYLE),
                    html.Div(labels_list, style={"overflowY": "auto", "maxHeight": "440px"}),
                ], style={**CARD_STYLE, "flex": "1"}),
            ], style={"display": "flex", "gap": "12px"}),

            # Evolución de subredes de acuerdo a lo largo del tiempo
            html.Div("SECUENCIA DE SUBREDES", style={**LABEL_STYLE, "marginBottom": "8px"}),
            html.Div([
                html.Div([
                    html.Span(f"t{i} ", style={"color": "#8b949e", "fontSize": "10px", "fontFamily": "JetBrains Mono"}),
                    html.Span(f"S{sid}",
                              style={"color": ACCENT2 if sid == trans_data["full_sync_id"] else ACCENT,
                                     "fontSize": "11px", "fontFamily": "JetBrains Mono",
                                     "backgroundColor": "#ffffff0a", "padding": "2px 6px",
                                     "borderRadius": "4px", "marginRight": "4px"}),
                ], style={"display": "inline-block", "margin": "2px"})
                for i, sid in enumerate(trans_data["subnet_sequence"])
            ], style={**CARD_STYLE, "flexWrap": "wrap", "display": "flex"}),
        ])

    # ── Tab 4: Mapa de regímenes (vacío hasta que se calcule vía botón) ───────
    elif tab == "tab-regime":
        return html.Div([
            html.Div("Usa el botón en la pestaña ② para calcular el mapa de regímenes.",
                     style={"color": "#8b949e", "fontFamily": "JetBrains Mono", "padding": "40px", "textAlign": "center"}),
        ])

    return html.Div()


# Callback para exploración exhaustiva
@app.callback(
    Output("explore-results-container", "children"),
    Input("btn-explore", "n_clicks"),
    State("param-N", "value"),
    State("param-M", "value"),
    State("param-kappa", "value"),
    State("param-omega", "value"),
    State("param-epsilon", "value"),
    State("param-maxsteps", "value"),
    State("graph-type", "value"),
    prevent_initial_call=True,
)
def run_exploration(n_clicks, N, M, kappa, omega, epsilon, max_steps, graph_type):
    if not n_clicks:
        return []

    total = M ** N
    if total > 10000:
        return html.Div(
            f"⛔ {M}^{N} = {total:,} configuraciones es demasiado para exploración exhaustiva en el browser. Reduce N ≤ 6 o M ≤ 6.",
            style={"color": "#f85149", "fontFamily": "JetBrains Mono", "fontSize": "12px", "padding": "12px",
                   "backgroundColor": "#200d0d", "border": "1px solid #f8514966", "borderRadius": "8px"}
        )

    G, adj = get_graph_and_adjacency(graph_type, N)
    result = explore_exhaustive(adj, N, M, int(omega), float(kappa), int(max_steps))
    p = result["proportions"]

    # Gráfico de barras de proporciones
    bar_fig = go.Figure(go.Bar(
        x=["Sync", "Punto Fijo", "Ciclo", "Transitorio"],
        y=[p["sync"], p["fixed_point"], p["cycle"], p["transient"]],
        marker_color=[ACCENT2, "#f5a623", "#e040fb", "#4a9eff"],
        text=[f"{v*100:.1f}%" for v in [p["sync"], p["fixed_point"], p["cycle"], p["transient"]]],
        textposition="outside",
    ))
    bar_fig.update_layout(
        **BASE_LAYOUT,
        title=f"Clasificación de {total:,} configuraciones — κ={kappa}",
        yaxis=dict(range=[0, 1.15], tickformat=".0%"),
        showlegend=False,
    )

    # Histograma de tiempos
    hist_fig = fig_sync_time_hist(result["sync_times"])

    return html.Div([
        html.Div([
            html.Div([
                html.Div("ρ_sync", style=LABEL_STYLE),
                html.Div(f"{p['sync']*100:.1f}%", style={"color": ACCENT2, "fontSize": "2rem", "fontFamily": "Space Grotesk", "fontWeight": "700"}),
            ], style={**CARD_STYLE, "flex": "1", "textAlign": "center"}),
            html.Div([
                html.Div("ρ_fix", style=LABEL_STYLE),
                html.Div(f"{p['fixed_point']*100:.1f}%", style={"color": "#f5a623", "fontSize": "2rem", "fontFamily": "Space Grotesk", "fontWeight": "700"}),
            ], style={**CARD_STYLE, "flex": "1", "textAlign": "center"}),
            html.Div([
                html.Div("ρ_cyc", style=LABEL_STYLE),
                html.Div(f"{p['cycle']*100:.1f}%", style={"color": "#e040fb", "fontSize": "2rem", "fontFamily": "Space Grotesk", "fontWeight": "700"}),
            ], style={**CARD_STYLE, "flex": "1", "textAlign": "center"}),
        ], style={"display": "flex", "gap": "12px"}),

        html.Div([
            html.Div([
                dcc.Graph(figure=bar_fig, config={"displayModeBar": False}, style={"height": "320px"})
            ], style={**CARD_STYLE, "flex": "1"}),
            html.Div([
                dcc.Graph(figure=hist_fig, config={"displayModeBar": False}, style={"height": "320px"})
            ], style={**CARD_STYLE, "flex": "1"}),
        ], style={"display": "flex", "gap": "12px"}),
    ])


# Callback para mapa de regímenes
@app.callback(
    Output("regime-map-container", "children"),
    Input("btn-regime", "n_clicks"),
    State("param-N", "value"),
    State("param-M", "value"),
    State("param-omega", "value"),
    State("param-maxsteps", "value"),
    State("graph-type", "value"),
    State("kappa-range-slider", "value"),
    prevent_initial_call=True,
)
def run_regime_map(n_clicks, N, M, omega, max_steps, graph_type, kappa_range):
    if not n_clicks:
        return []

    total = M ** N
    if total > 2000:
        return html.Div(
            f"⚠ {M}^{N} = {total:,} configuraciones. Reduciendo pasos a 50 para acelerar el barrido.",
            style={"color": "#f5a623", "fontFamily": "JetBrains Mono", "fontSize": "12px"}
        )

    G, adj = get_graph_and_adjacency(graph_type, N)
    kmin, kmax = kappa_range
    kappa_vals = list(np.arange(kmin, kmax + 0.5, 1.0))
    regime = sweep_kappa(adj, N, M, int(omega), kappa_vals, max_steps=min(int(max_steps), 80))

    fig = fig_regime_map(regime)

    return html.Div([
        dcc.Graph(figure=fig, config={"displayModeBar": True}, style={"height": "420px"})
    ], style=CARD_STYLE)


if __name__ == "__main__":
    app.run(debug=True, port=8050)
