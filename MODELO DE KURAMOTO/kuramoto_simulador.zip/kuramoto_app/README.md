# Simulador de Sincronización Discreta tipo Kuramoto sobre Grafos

Plataforma de simulación computacional para redes discretas de Kuramoto con umbral sobre grafos finitos.

## Modelo matemático

La dinámica central implementa la regla:

```
(F_κ(θ))_i = θ_i + ω* + σ_κ(S_i(θ))   (mod M)
```

donde:
- `S_i(θ) = Σ_{j∈N(i)} d_M^signed(θ_j, θ_i)`  — suma de acoplamiento con signo
- `d_M(a,b) = min(|a-b|, M-|a-b|)`  — distancia circular en Z_M
- `σ_κ(s) = +1` si `s > κ`, `-1` si `s < -κ`, `0` si `|s| ≤ κ`

El espacio de configuraciones es `X_M = Z_M^V`, con `|X_M| = M^N`.

La diagonal sincronizada es `Δ_M = {θ : θ_i = θ_j ∀ i,j ∈ V}`.

## Módulos

### ① Simulación individual
Estudia una condición inicial específica. Muestra:
- Heatmap de evolución de fases θ_i(t)
- Parámetro de orden de Kuramoto r(t)
- Snapshots del grafo coloreado por fase
- Tabla completa: θ_t, S_i(θ_t), σ_κ(S_i)
- Clasificación del atractor: sync / punto fijo / ciclo / transitorio

### ② Exploración exhaustiva
Recorre todo el espacio M^N y calcula:
- ρ_sync(κ): proporción de configuraciones que sincronizan
- ρ_fix(κ): proporción que caen en punto fijo no trivial
- ρ_cyc(κ): proporción que entran en ciclo periódico
- Histograma de tiempos de sincronización
- Comparación con número de Bell B_N

### ③ Diagrama de transiciones
Construye el grafo dirigido de subredes de acuerdo:
- `G^ε_{θ_t} = (V, E^ε_{θ_t})` donde `(i,j) ∈ E^ε` ssi `d_M(θ_i, θ_j) ≤ ε`
- Nodos = subredes realizadas dinámicamente
- Aristas = transiciones observadas
- Identificación de caminos hacia sincronización

### ④ Mapa de regímenes
Barrido de κ que genera el mapa ρ(κ) completo para clasificar:
- Régimen débil (κ pequeño)
- Régimen de máxima sincronización
- Régimen fuerte (κ grande, cercano al trivial)

## Grafos soportados

| Tipo     | Descripción               |
|----------|---------------------------|
| K_N      | Completo                  |
| P_N      | Camino                    |
| C_N      | Ciclo                     |
| Estrella | Hub central + N-1 hojas   |

## Instalación local

```bash
git clone <repo>
cd kuramoto_app
pip install -r requirements.txt
python app.py
# Abre http://localhost:8050
```

## Deployment en Render

1. Sube el repositorio a GitHub
2. En [render.com](https://render.com): New → Web Service → conecta el repo
3. Render detecta automáticamente `render.yaml`
4. Build: `pip install -r requirements.txt`
5. Start: `gunicorn app:server --workers 2 --threads 2 --timeout 120 --bind 0.0.0.0:$PORT`

## Estructura del proyecto

```
kuramoto_app/
├── app.py                    # Aplicación Dash principal
├── requirements.txt          # Dependencias Python
├── render.yaml               # Configuración Render
├── Procfile                  # Fallback deployment
├── README.md
└── core/
    ├── __init__.py
    ├── graph.py              # Construcción de grafos (NetworkX)
    ├── dynamics.py           # Motor de dinámica discreta de Kuramoto
    ├── exploration.py        # Exploración exhaustiva + barrido κ
    ├── transitions.py        # Subredes de acuerdo + diagrama de transiciones
    └── visualizations.py     # Todas las figuras Plotly
```

## Dependencias

- `dash` + `dash-bootstrap-components`: framework web
- `plotly`: visualizaciones interactivas
- `networkx`: manejo de grafos
- `numpy`: cómputo numérico
- `gunicorn`: servidor WSGI para producción
